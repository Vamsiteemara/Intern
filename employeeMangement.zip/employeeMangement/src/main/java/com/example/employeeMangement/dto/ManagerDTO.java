package com.example.employeeMangement.dto;

import lombok.Data;

@Data
public class ManagerDTO {
    private String id;
    private String name;
}
