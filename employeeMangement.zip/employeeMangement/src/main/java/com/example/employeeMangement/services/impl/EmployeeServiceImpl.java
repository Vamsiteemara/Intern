package com.example.employeeMangement.services.impl;

import com.example.employeeMangement.dto.EmployeeAddDTO;
import com.example.employeeMangement.dto.EmployeeDTO;
import com.example.employeeMangement.dto.EmployeeMangerDTO;
import com.example.employeeMangement.entity.Employee;
import com.example.employeeMangement.entity.Manager;
import com.example.employeeMangement.repository.EmployeeRepository;
import com.example.employeeMangement.repository.ManagerRepository;
import com.example.employeeMangement.services.EmployeeService;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class EmployeeServiceImpl implements EmployeeService {
    @Autowired
    EmployeeRepository employeeRepository;
    @Autowired
    ManagerRepository managerRepository;
    public void addOrUpdateEmployee(EmployeeAddDTO employeeAddDTO) {
        EmployeeDTO employeeDTO=new EmployeeDTO();
        BeanUtils.copyProperties(employeeAddDTO,employeeDTO);
        Optional<Manager> optionalManager=managerRepository.findById(employeeAddDTO.getManagersId());
        employeeDTO.setManager(optionalManager.get());
        Employee employee=new Employee();
        BeanUtils.copyProperties(employeeDTO,employee);
        employeeRepository.save(employee);

    }

    @Override
    public void removeEmployee(String employeeId) {
        Optional<Employee> optionalEmployee=employeeRepository.findById(employeeId);
        if(optionalEmployee.isPresent()){
            employeeRepository.delete(optionalEmployee.get());
        }
    }

    public List<Employee> getAllEmployeesUnderOneManager(String managerId){
      return employeeRepository.getListOfEmployeesUnderManager(managerId);
    }
    public Optional<Employee> getEmployeeById(String empId){
        return employeeRepository.findById(empId);
    }
    public EmployeeMangerDTO getAllManagerOfEmployee(String employeeId){
        EmployeeMangerDTO employeeMangerDTO=new EmployeeMangerDTO();
        employeeMangerDTO.setEmployeeId(employeeId);
        List<Manager> managerList=new ArrayList<>();
        employeeMangerDTO.setManagersList(managerList);
        Optional<Employee> optionalEmployee=employeeRepository.findById(employeeId);
        if(optionalEmployee.isPresent()){
            Employee employee=optionalEmployee.get();
            employeeMangerDTO.setEmployeeName(employee.getName());
            List<Manager> managers=employeeMangerDTO.getManagersList();
            managers.add(employee.getManager());
            employeeMangerDTO.setManagersList(managers);
            while(employeeRepository.findById(employee.getManager().getId()).isPresent()){
                Optional<Employee> optionalEmployee1=employeeRepository.findById(employee.getManager().getId());
                employee=optionalEmployee1.get();
                employeeMangerDTO.getManagersList().add(employee.getManager());
        }
        }
        else{
            return employeeMangerDTO;
        }
        return  employeeMangerDTO;
    }
    public Iterable<Employee> getAll(){
        return employeeRepository.getAllManagers();
    }
}
