package com.example.employeeMangement.controller;
import com.example.employeeMangement.dto.EmployeeAddDTO;
import com.example.employeeMangement.dto.EmployeeDTO;
import com.example.employeeMangement.dto.EmployeeMangerDTO;
import com.example.employeeMangement.entity.Employee;
import com.example.employeeMangement.services.EmployeeService;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
public class EmployeeController {
    @Autowired
    EmployeeService employeeService;


    @PostMapping("/addOrUpdateEmployee")
    public ResponseEntity<Boolean> addOrUpdate(@RequestBody EmployeeAddDTO employeeAddDTO){
        employeeService.addOrUpdateEmployee(employeeAddDTO);
        return  new ResponseEntity<>(Boolean.TRUE,HttpStatus.OK);
    }
    @DeleteMapping("/removeEmployeeById")
    public ResponseEntity<Boolean> remove(@RequestParam("employeeId") String employeeId){
        employeeService.removeEmployee(employeeId);
        return new ResponseEntity<>(Boolean.TRUE,HttpStatus.OK);
    }
    @GetMapping("/getEmployeeById")
    public ResponseEntity<EmployeeDTO> getEmployeeById(@RequestParam("employeeeId") String employeeId){
        Optional<Employee> employee = employeeService.getEmployeeById(employeeId);
        EmployeeDTO employeeDTO=new EmployeeDTO();
        BeanUtils.copyProperties(employee.get(), employeeDTO);
        return new ResponseEntity<>(employeeDTO,HttpStatus.OK);
    }
    @GetMapping("/getEmployeesUnderOneManger")
    public ResponseEntity<List<Employee>> getEmployeesUnderOneManager(@RequestParam("managerId") String managerId){
        return new ResponseEntity<>(employeeService.getAllEmployeesUnderOneManager(managerId),HttpStatus.OK);
    }
    @GetMapping("/getAllMangersForEmployee")
    public ResponseEntity<EmployeeMangerDTO> getAllManagers(@RequestParam("employeeId") String employeeId){
        return new ResponseEntity<>(employeeService.getAllManagerOfEmployee(employeeId),HttpStatus.OK);
    }
    @GetMapping("getAllEmployees")
    public ResponseEntity<Iterable<Employee>> getAllEmployees(){
        return new ResponseEntity<>(employeeService.getAll(),HttpStatus.OK);
    }

}
