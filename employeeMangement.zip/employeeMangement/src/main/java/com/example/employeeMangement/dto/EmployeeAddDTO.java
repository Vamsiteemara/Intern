package com.example.employeeMangement.dto;

import lombok.Data;

@Data
public class EmployeeAddDTO {
    private String empId;
    private String name;
    private String ManagersId;
}
