package com.example.employeeMangement.dto;

import com.example.employeeMangement.entity.Manager;
import lombok.Data;

import java.util.List;

@Data
public class EmployeeMangerDTO {
    private String employeeId;
    private String employeeName;
    private List<Manager> managersList;
}
