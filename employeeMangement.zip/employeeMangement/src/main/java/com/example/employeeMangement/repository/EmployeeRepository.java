package com.example.employeeMangement.repository;

import com.example.employeeMangement.entity.Employee;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface EmployeeRepository extends CrudRepository<Employee,String> {
    @Query(value = "SELECT * FROM employee WHERE manager_id=?1", nativeQuery=true)
    List<Employee> getListOfEmployeesUnderManager(String managerId);
@Query(value = "SELECT * FROM employee", nativeQuery=true)
  Iterable<Employee> getAllManagers();
}
