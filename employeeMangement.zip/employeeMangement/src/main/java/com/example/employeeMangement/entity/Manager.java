package com.example.employeeMangement.entity;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Data
@Table
@Entity
public class Manager {
    @Id
    private String id;
    private String name;
}
