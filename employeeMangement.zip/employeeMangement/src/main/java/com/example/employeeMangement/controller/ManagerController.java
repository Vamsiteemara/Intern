package com.example.employeeMangement.controller;

import com.example.employeeMangement.dto.ManagerDTO;
import com.example.employeeMangement.entity.Manager;
import com.example.employeeMangement.services.ManagerService;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
public class ManagerController {
    @Autowired
    ManagerService managerService;
    @PostMapping("/addOrUpdateManager")
    public ResponseEntity<Boolean> addManager(@RequestBody ManagerDTO managerDTO){
        managerService.addManger(managerDTO);
        return new ResponseEntity<>(Boolean.TRUE,HttpStatus.OK);
    }
    @DeleteMapping("deleteManagerById")
    public ResponseEntity<Boolean> deleteManager(@RequestParam("id") String managerId){
        managerService.deleteManager(managerId);
        return new ResponseEntity<>(Boolean.TRUE,HttpStatus.OK);
    }
    @GetMapping("getManagerById")
    public ResponseEntity<ManagerDTO> getManagerById(@RequestParam("managerId") String managerId){
        Optional<Manager> manager=managerService.getManagerById(managerId);
        ManagerDTO managerDTO=new ManagerDTO();
        BeanUtils.copyProperties(manager.get(), managerDTO);
        return new ResponseEntity<>(managerDTO,HttpStatus.OK);
    }
 @GetMapping("getAllManagers")
    public ResponseEntity<Iterable<Manager>> getAllManagers(){
        return new ResponseEntity<>(managerService.getAll(),HttpStatus.OK);
 }
}
