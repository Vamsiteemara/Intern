package com.example.employeeMangement.repository;
import com.example.employeeMangement.entity.Manager;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ManagerRepository extends CrudRepository<Manager,String> {
    @Query(value = "SELECT * FROM manager", nativeQuery=true)
    Iterable<Manager> getAllManagers();
}
