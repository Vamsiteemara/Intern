package com.example.employeeMangement.services;

import com.example.employeeMangement.dto.ManagerDTO;
import com.example.employeeMangement.entity.Manager;

import java.util.Optional;

public interface ManagerService{
    void addManger(ManagerDTO managerDTO);
    void deleteManager(String managerId);
    Optional<Manager> getManagerById(String managerId);
    Iterable<Manager> getAll();
}
