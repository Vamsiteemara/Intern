package com.example.employeeMangement.services;

import com.example.employeeMangement.dto.EmployeeAddDTO;
import com.example.employeeMangement.dto.EmployeeDTO;
import com.example.employeeMangement.dto.EmployeeMangerDTO;
import com.example.employeeMangement.entity.Employee;

import java.util.List;
import java.util.Optional;

public interface EmployeeService {
    void addOrUpdateEmployee(EmployeeAddDTO employeeAddDTO);
     void removeEmployee(String employeeId);
    List<Employee> getAllEmployeesUnderOneManager(String managerId);
    Optional<Employee> getEmployeeById(String empId);
    EmployeeMangerDTO getAllManagerOfEmployee(String employeeId);
    Iterable<Employee> getAll();
}
