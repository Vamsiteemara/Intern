package com.example.employeeMangement.services.impl;

import com.example.employeeMangement.dto.ManagerDTO;
import com.example.employeeMangement.entity.Manager;
import com.example.employeeMangement.repository.ManagerRepository;
import com.example.employeeMangement.services.ManagerService;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
@Service
public class ManagerServiceImpl implements ManagerService{
    @Autowired
    ManagerRepository managerRepository;
    @Override
    public void addManger(ManagerDTO managerDTO) {
        Manager manager=new Manager();
        BeanUtils.copyProperties(managerDTO,manager);
        managerRepository.save(manager);
    }
    public void deleteManager(String managerId) {
        Optional<Manager> optionalManager = managerRepository.findById(managerId);
        if (optionalManager.isPresent()) {
            managerRepository.delete(optionalManager.get());
        }
    }
    public Optional<Manager> getManagerById(String managerId){
        return managerRepository.findById(managerId);
    }
    public Iterable<Manager> getAll(){
        return managerRepository.getAllManagers();
    }
}
