package com.example.employeeMangement.dto;

import com.example.employeeMangement.entity.Manager;
import lombok.Data;

@Data
public class EmployeeDTO {
    private String empId;
    private String name;
    private Manager manager;
}
