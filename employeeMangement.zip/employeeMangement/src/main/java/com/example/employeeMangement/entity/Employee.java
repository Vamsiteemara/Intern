package com.example.employeeMangement.entity;

import lombok.Data;

import javax.persistence.*;

@Data
@Table
@Entity
public class Employee {
    @Id
    private String empId;
    private String name;
    @ManyToOne
    @JoinColumn(name = "manager_id",referencedColumnName = "id")
    private Manager manager;
}
