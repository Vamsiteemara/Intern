package com.example.employeeMangement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeMangementApplicationTests {

	@Test
	void contextLoads() {
	}

}
